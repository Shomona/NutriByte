//Name: Shomona Mukherjee
//Andrew Id: shomonam
package hw1;

public class Product {
	String ndbNumber;
	String productName;
	String manufarurer;
	String ingredients;
	float servingSize;
	String servingUom;
	float householdSize;
	String householdUom;

	public Product(String ndbNumber, String productName, String manufacturer, String ingredients) {
		this.ndbNumber = ndbNumber;
		this.productName = productName;
		this.manufarurer = manufacturer;
		this.ingredients = ingredients;
	}

}
