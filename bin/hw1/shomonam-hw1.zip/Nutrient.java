//Name: Shomona Mukherjee
//Andrew Id: shomonam
package hw1;

public class Nutrient {

	String nutrientCode;
	String nutrientName;
	String nutrientUom;

	public Nutrient(String nutrientCode, String nutrientName, String nutrientUom) {
		this.nutrientCode = nutrientCode;
		this.nutrientName = nutrientName;
		this.nutrientUom = nutrientUom;		
	}


}
