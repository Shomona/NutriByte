//Name: Shomona Mukherjee
//Andrew Id: shomonam
package hw1;

public class ProductNutrient {

	String ndbNumber;
	String nutrientCode;
	String nutrientName;
	float quantity;
	String nutrientUom;

	public ProductNutrient(String ndbNumber, String nutrientCode, String nutrientName, float quantity, String nutrientUom) {
		this.ndbNumber = ndbNumber;
		this.nutrientCode = nutrientCode;
		this.nutrientName = nutrientName;
		this.quantity = quantity;
		this.nutrientUom = nutrientUom;
	}
}
